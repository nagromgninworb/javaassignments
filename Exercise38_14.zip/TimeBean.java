package chapter38;

import java.util.*;

public class TimeBean {
    public String[] getAllLocale() {
        Locale[] locales = Locale.getAvailableLocales();
        String[] localeNames = new String[locales.length];
        for (int i = 0; i < locales.length; i++) {
            localeNames[i] = locales[i].getDisplayName();
        }
        return localeNames;
    }

    public String[] getAllTimeZone() {
        String[] timeZones = TimeZone.getAvailableIDs();
        Arrays.sort(timeZones);
        return timeZones;
    }

    public String getCurrentTime(int localeIndex, int timeZoneIndex) {
        Locale[] locales = Locale.getAvailableLocales();
        String[] timeZones = TimeZone.getAvailableIDs();

        Locale locale = locales[localeIndex];
        TimeZone timeZone = TimeZone.getTimeZone(timeZones[timeZoneIndex]);

        Calendar calendar = new GregorianCalendar(timeZone, locale);
        return calendar.getTime().toString();
    }
}
