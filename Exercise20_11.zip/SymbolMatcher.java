import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Stack;

public class SymbolMatcher {
    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Usage: java SymbolMatcher <JavaSourceFile>");
            return;
        }

        String filename = args[0];
        Stack<Character> stack = new Stack<>();

        try {
            Scanner input = new Scanner(new File(filename));
            while (input.hasNextLine()) {
                String line = input.nextLine();
                for (char ch : line.toCharArray()) {
                    if (ch == '(' || ch == '{' || ch == '[') {
                        stack.push(ch);
                    } else if (ch == ')' || ch == '}' || ch == ']') {
                        if (stack.isEmpty()) {
                            System.out.println("Unmatched closing " + ch);
                            return;
                        }
                        char open = stack.pop();
                        if (!isMatchingPair(open, ch)) {
                            System.out.println("Mismatched pair: " + open + " and " + ch);
                            return;
                        }
                    }
                }
            }

            if (stack.isEmpty()) {
                System.out.println("All grouping symbols are correctly matched.");
            } else {
                System.out.println("Unmatched opening symbol(s) remaining.");
            }

            input.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + filename);
        }
    }

    public static boolean isMatchingPair(char open, char close) {
        return (open == '(' && close == ')') ||
               (open == '{' && close == '}') ||
               (open == '[' && close == ']');
    }
}
