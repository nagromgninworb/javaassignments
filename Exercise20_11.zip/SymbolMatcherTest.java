public class SymbolMatcherTest {
    public static void main(String[] args) {
        System.out.println("Hello, world!"); // Simple print

        int[] numbers = {1, 2, 3};
        for (int i = 0; i < numbers.length; i++) {
            if (numbers[i] % 2 == 0) {
                System.out.println(numbers[i] + " is even.");
            }
        }
    }
}

