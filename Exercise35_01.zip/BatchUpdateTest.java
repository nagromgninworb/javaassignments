import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.*;

public class BatchUpdateTest extends Application {
    private TextArea taOutput = new TextArea();

    @Override
    public void start(Stage primaryStage) {
        Button btnRun = new Button("Run Insert Test");
        btnRun.setOnAction(e -> runInsertTest());

        VBox pane = new VBox(10, btnRun, taOutput);
        pane.setPadding(new Insets(10));

        primaryStage.setScene(new Scene(pane, 500, 400));
        primaryStage.setTitle("Exercise 35.1 - Batch Update Test");
        primaryStage.show();
    }

    private void runInsertTest() {
        String url = "jdbc:mysql://localhost:3306/javaproject";
        String user = "root";
        String password = "";

        String insertSQL = "INSERT INTO Temp (num1, num2, num3) VALUES (?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            Statement clearStmt = conn.createStatement();
            clearStmt.execute("DELETE FROM Temp");

            // Without batch
            long start1 = System.currentTimeMillis();
            try (PreparedStatement ps = conn.prepareStatement(insertSQL)) {
                for (int i = 0; i < 1000; i++) {
                    ps.setDouble(1, Math.random());
                    ps.setDouble(2, Math.random());
                    ps.setDouble(3, Math.random());
                    ps.executeUpdate();
                }
            }
            long end1 = System.currentTimeMillis();

            // Clear table again
            clearStmt.execute("DELETE FROM Temp");

            // With batch
            long start2 = System.currentTimeMillis();
            try (PreparedStatement ps = conn.prepareStatement(insertSQL)) {
                for (int i = 0; i < 1000; i++) {
                    ps.setDouble(1, Math.random());
                    ps.setDouble(2, Math.random());
                    ps.setDouble(3, Math.random());
                    ps.addBatch();
                }
                ps.executeBatch();
            }
            long end2 = System.currentTimeMillis();

            taOutput.setText("Without batch time: " + (end1 - start1) + " ms\n" +
                             "With batch time: " + (end2 - start2) + " ms");

        } catch (Exception ex) {
            taOutput.setText("Error: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}

