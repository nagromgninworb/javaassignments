import java.math.BigInteger;
import java.util.Scanner;

public class Exercise13_15 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Prompt user for first rational number
        System.out.print("Enter rational r1 with numerator and denominator separated by a space: ");
        String n1 = input.next();
        String d1 = input.next();

        // Prompt user for second rational number
        System.out.print("Enter rational r2 with numerator and denominator separated by a space: ");
        String n2 = input.next();
        String d2 = input.next();

        RationalUsingBigInteger r1 = new RationalUsingBigInteger(
            new BigInteger(n1), new BigInteger(d1));
        RationalUsingBigInteger r2 = new RationalUsingBigInteger(
            new BigInteger(n2), new BigInteger(d2));

        // Perform operations and display results
        System.out.println(r1 + " + " + r2 + " = " + r1.add(r2));
        System.out.println(r1 + " - " + r2 + " = " + r1.subtract(r2));
        System.out.println(r1 + " * " + r2 + " = " + r1.multiply(r2));
        System.out.println(r1 + " / " + r2 + " = " + r1.divide(r2));
        System.out.println(r2 + " is " + r2.doubleValue());
    }
}
