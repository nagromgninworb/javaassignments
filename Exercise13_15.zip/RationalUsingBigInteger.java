import java.math.BigInteger;

public class RationalUsingBigInteger implements Comparable<RationalUsingBigInteger> {
    private BigInteger numerator = BigInteger.ZERO;
    private BigInteger denominator = BigInteger.ONE;

    public RationalUsingBigInteger(BigInteger numerator, BigInteger denominator) {
        BigInteger gcd = numerator.gcd(denominator);
        if (denominator.compareTo(BigInteger.ZERO) < 0) {
            gcd = gcd.negate();
        }
        this.numerator = numerator.divide(gcd);
        this.denominator = denominator.divide(gcd);
    }

    public BigInteger getNumerator() {
        return numerator;
    }

    public BigInteger getDenominator() {
        return denominator;
    }

    public RationalUsingBigInteger add(RationalUsingBigInteger r) {
        BigInteger n = numerator.multiply(r.getDenominator())
            .add(denominator.multiply(r.getNumerator()));
        BigInteger d = denominator.multiply(r.getDenominator());
        return new RationalUsingBigInteger(n, d);
    }

    public RationalUsingBigInteger subtract(RationalUsingBigInteger r) {
        BigInteger n = numerator.multiply(r.getDenominator())
            .subtract(denominator.multiply(r.getNumerator()));
        BigInteger d = denominator.multiply(r.getDenominator());
        return new RationalUsingBigInteger(n, d);
    }

    public RationalUsingBigInteger multiply(RationalUsingBigInteger r) {
        BigInteger n = numerator.multiply(r.getNumerator());
        BigInteger d = denominator.multiply(r.getDenominator());
        return new RationalUsingBigInteger(n, d);
    }

    public RationalUsingBigInteger divide(RationalUsingBigInteger r) {
        BigInteger n = numerator.multiply(r.getDenominator());
        BigInteger d = denominator.multiply(r.getNumerator());
        return new RationalUsingBigInteger(n, d);
    }

    public double doubleValue() {
        return numerator.doubleValue() / denominator.doubleValue();
    }

    @Override
    public String toString() {
        if (denominator.equals(BigInteger.ONE)) {
            return numerator.toString();
        } else {
            return numerator + "/" + denominator;
        }
    }

    @Override
    public int compareTo(RationalUsingBigInteger o) {
        BigInteger left = numerator.multiply(o.getDenominator());
        BigInteger right = denominator.multiply(o.getNumerator());
        return left.compareTo(right);
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof RationalUsingBigInteger)) return false;
        RationalUsingBigInteger other = (RationalUsingBigInteger) obj;
        return this.compareTo(other) == 0;
    }
}

