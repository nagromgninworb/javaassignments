public class TestCircle {
    public static void main(String[] args) {
        Circle circle1 = new Circle(5.0);
        Circle circle2 = new Circle(3.0);
        Circle circle3 = new Circle(5.0);

        System.out.println(circle1);
        System.out.println(circle2);
        System.out.println(circle3);

        System.out.println("\nComparing circle1 and circle2: " + circle1.compareTo(circle2));
        System.out.println("Comparing circle1 and circle3: " + circle1.compareTo(circle3));

        System.out.println("\nIs circle1 equal to circle2? " + circle1.equals(circle2));
        System.out.println("Is circle1 equal to circle3? " + circle1.equals(circle3));
    }
}
