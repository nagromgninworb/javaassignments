public class Circle extends GeometricObject implements Comparable<Circle> {
    private double radius;

    public Circle() {
        this.radius = 1.0;
    }

    public Circle(double radius) {
        this.radius = radius;
    }

    public double getRadius() {
        return radius;
    }

    public double getArea() {
        return Math.PI * radius * radius;
    }

    public double getPerimeter() {
        return 2 * Math.PI * radius;
    }

    @Override
    public int compareTo(Circle other) {
        return Double.compare(this.getArea(), other.getArea());
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Circle) {
            return this.radius == ((Circle) obj).radius;
        }
        return false;
    }

    @Override
    public String toString() {
        return "Circle radius = " + radius + ", area = " + getArea();
    }
}
