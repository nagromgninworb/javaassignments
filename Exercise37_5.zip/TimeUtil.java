import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.ZoneId;
import java.util.Locale;

public class TimeUtil {
    public static String getCurrentTime(String localeStr, String zoneStr) {
        try {
            Locale locale = Locale.forLanguageTag(localeStr);
            ZoneId zone = ZoneId.of(zoneStr);
            ZonedDateTime now = ZonedDateTime.now(zone);

            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy h:mm a", locale);
            return formatter.format(now);
        } catch (Exception e) {
            return "Invalid locale or timezone.";
        }
    }
}
