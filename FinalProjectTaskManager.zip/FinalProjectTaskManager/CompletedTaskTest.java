// Test class for CompletedTask-specific methods
public class CompletedTaskTest {
    public static void main(String[] args) {
        // Create a completed task
        CompletedTask ct = new CompletedTask("Project", "Final project submitted", "2025-04-18", 3, true);
        System.out.println(ct.toString());

        // Archive the task
        ct.archive();
    }
}
