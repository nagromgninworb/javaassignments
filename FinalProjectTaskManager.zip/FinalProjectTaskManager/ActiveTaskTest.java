// Test class for ActiveTask-specific methods
public class ActiveTaskTest {
    public static void main(String[] args) {
        // Create an active task
        ActiveTask task = new ActiveTask("Test Task", "Initial description", "2025-05-01", 2, false);

        // Print initial state
        System.out.println(task.toString());

        // Test markComplete
        task.markComplete();

        // Update some fields using setters
        task.setDescription("Updated Description");
        task.setDueDate("2025-05-10");
        task.setCompleted(true);

        // Print updated state
        System.out.println(task.toString());
    }
}


