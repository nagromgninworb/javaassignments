// Represents a task that is currently active
public class ActiveTask extends Task {
    // Constructor uses superclass constructor
    public ActiveTask(String name, String description, String dueDate, int priority, boolean completed) {
        super(name, description, dueDate, priority, completed);
    }

    // Marks the task as complete
    public void markComplete() {
        setCompleted(true);
    }

    // Custom string for active tasks
    public String toString() {
        return "[Active] " + super.toString();
    }
}

