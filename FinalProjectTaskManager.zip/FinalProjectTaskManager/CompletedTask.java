// Represents a task that has already been completed
public class CompletedTask extends Task {
    // Constructor uses superclass constructor
    public CompletedTask(String name, String description, String dueDate, int priority, boolean completed) {
        super(name, description, dueDate, priority, completed);
    }

    // Archives the completed task (placeholder method)
    public void archive() {
        System.out.println("Task archived.");
    }

    // Custom string for completed tasks
    public String toString() {
        return "[Completed] " + super.toString();
    }
}

