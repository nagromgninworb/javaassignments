// Test class for the Task functionality using ActiveTask
public class TaskTest {
    public static void main(String[] args) {
        // Create a sample active task
        Task t = new ActiveTask("Test Task", "description", "2025-04-25", 2, false);
        System.out.println(t.toString());

        // Update some fields and print updated task
        t.setDescription("Updated Description");
        t.setDueDate("2025-05-10");
        t.setCompleted(true);
        System.out.println(t.toString());
    }
}


