// JavaFX GUI for Task Manager
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.util.ArrayList;

public class TaskManagerGUI extends Application {
    private ArrayList<Task> tasks = new ArrayList<>();
    private TextArea taskDisplay = new TextArea();

    public void start(Stage primaryStage) {
        // Input fields
        TextField nameField = new TextField();
        TextField descField = new TextField();
        TextField dueDateField = new TextField();
        TextField priorityField = new TextField();

        // Buttons
        Button addTaskBtn = new Button("Add Active Task");
        Button markCompleteBtn = new Button("Mark Complete");
        Button archiveBtn = new Button("Archive Completed");

        // Layouts
        GridPane inputPane = new GridPane();
        inputPane.setHgap(10);
        inputPane.setVgap(10);
        inputPane.add(new Label("Name:"), 0, 0);
        inputPane.add(nameField, 1, 0);
        inputPane.add(new Label("Description:"), 0, 1);
        inputPane.add(descField, 1, 1);
        inputPane.add(new Label("Due Date:"), 0, 2);
        inputPane.add(dueDateField, 1, 2);
        inputPane.add(new Label("Priority:"), 0, 3);
        inputPane.add(priorityField, 1, 3);
        inputPane.add(addTaskBtn, 0, 4);
        inputPane.add(markCompleteBtn, 1, 4);
        inputPane.add(archiveBtn, 1, 5);

        // Display area
        taskDisplay.setEditable(false);
        VBox root = new VBox(10, inputPane, taskDisplay);
        root.setPadding(new javafx.geometry.Insets(10));

        // Event handlers
        addTaskBtn.setOnAction(e -> {
            String name = nameField.getText();
            String desc = descField.getText();
            String due = dueDateField.getText();
            int priority = Integer.parseInt(priorityField.getText());
            Task newTask = new ActiveTask(name, desc, due, priority, false);
            tasks.add(newTask);
            refreshDisplay();
        });

        markCompleteBtn.setOnAction(e -> {
            for (int i = 0; i < tasks.size(); i++) {
                if (tasks.get(i) instanceof ActiveTask && !tasks.get(i).isCompleted()) {
                    ((ActiveTask) tasks.get(i)).markComplete();
                    Task completed = new CompletedTask(
                            tasks.get(i).getName(),
                            tasks.get(i).getDescription(),
                            tasks.get(i).getDueDate(),
                            tasks.get(i).getPriority(),
                            true
                    );
                    tasks.set(i, completed);
                }
            }
            refreshDisplay();
        });

        archiveBtn.setOnAction(e -> {
            for (Task t : tasks) {
                if (t instanceof CompletedTask) {
                    ((CompletedTask) t).archive();
                }
            }
        });

        Scene scene = new Scene(root, 500, 500);
        primaryStage.setTitle("Task Manager");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void refreshDisplay() {
        StringBuilder sb = new StringBuilder();
        for (Task t : tasks) {
            sb.append(t.toString()).append("\n");
        }
        taskDisplay.setText(sb.toString());
    }

    public static void main(String[] args) {
        launch(args);
    }
}
