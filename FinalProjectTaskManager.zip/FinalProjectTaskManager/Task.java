// Abstract base class representing a general task
public abstract class Task {
    // Fields shared by all tasks
    private String name;
    private String description;
    private String dueDate;
    private int priority;
    private boolean completed;

    // Constructor
    public Task(String name, String description, String dueDate, int priority, boolean completed) {
        this.name = name;
        this.description = description;
        this.dueDate = dueDate;
        this.priority = priority;
        this.completed = completed;
    }

    // Getter and setter methods
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    public int getPriority() {
        return priority;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    // Returns a string representation of the task
    public String toString() {
        return "Name: " + name + ", Description: " + description + ", Due: " + dueDate + 
               ", Priority: " + priority + ", Completed: " + completed;
    }
}

