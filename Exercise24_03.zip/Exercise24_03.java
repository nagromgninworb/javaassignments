import java.util.Scanner;
import java.util.ListIterator;

public class Exercise24_03 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        TwoWayLinkedList<Double> list = new TwoWayLinkedList<>();

        System.out.println("Enter five numbers:");
        for (int i = 0; i < 5; i++) {
            list.add(input.nextDouble());
        }

        ListIterator<Double> iterator = list.listIterator();

        // Forward traversal
        while (iterator.hasNext()) {
            System.out.print(iterator.next() + " ");
        }

        System.out.println();

        // Now iterator is at the end — we can go backwards
        while (iterator.hasPrevious()) {
            System.out.print(iterator.previous() + " ");
        }

        System.out.println();
    }
}


