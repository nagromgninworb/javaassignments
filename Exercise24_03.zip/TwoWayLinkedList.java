import java.util.ListIterator;
import java.util.NoSuchElementException;

public class TwoWayLinkedList<E> {
    private Node<E> head;
    private Node<E> tail;
    private int size = 0;

    private static class Node<E> {
        E element;
        Node<E> next;
        Node<E> previous;

        public Node(E e) {
            element = e;
        }
    }

    public void add(E e) {
        Node<E> newNode = new Node<>(e);
        if (head == null) {
            head = tail = newNode;
        } else {
            tail.next = newNode;
            newNode.previous = tail;
            tail = newNode;
        }
        size++;
    }

    public E get(int index) {
        checkIndex(index);
        Node<E> current = head;
        for (int i = 0; i < index; i++)
            current = current.next;
        return current.element;
    }

    public ListIterator<E> listIterator() {
        return new TwoWayIterator(0);
    }

    public ListIterator<E> listIterator(int index) {
        return new TwoWayIterator(index);
    }

    private class TwoWayIterator implements ListIterator<E> {
        private Node<E> current;
        private int index;

        public TwoWayIterator(int index) {
            checkIndexForIterator(index);
            current = head;
            this.index = 0;
            while (this.index < index && current != null) {
                current = current.next;
                this.index++;
            }
        }

        public boolean hasNext() {
            return current != null;
        }

        public E next() {
            if (!hasNext())
                throw new NoSuchElementException();
            E element = current.element;
            current = current.next;
            index++;
            return element;
        }

        public boolean hasPrevious() {
            return current != null && current.previous != null;
        }

        public E previous() {
            if (!hasPrevious())
                throw new NoSuchElementException();
            current = current.previous;
            index--;
            return current.element;
        }

        public int nextIndex() {
            return index;
        }

        public int previousIndex() {
            return index - 1;
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }

        public void set(E e) {
            throw new UnsupportedOperationException();
        }

        public void add(E e) {
            throw new UnsupportedOperationException();
        }
    }

    private void checkIndex(int index) {
        if (index < 0 || index >= size)
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
    }

    private void checkIndexForIterator(int index) {
        if (index < 0 || index > size)
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
    }
}

