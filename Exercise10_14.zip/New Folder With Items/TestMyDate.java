public class TestMyDate {
    public static void main(String[] args) {
        // Create first MyDate object with no arguments (current date)
        MyDate date1 = new MyDate();

        // Create second MyDate object using elapsed time
        MyDate date2 = new MyDate(34355555133101L);

        // Display both dates
        System.out.println("Date 1: " + date1.getYear() + "-" + date1.getMonth() + "-" + date1.getDay());
        System.out.println("Date 2: " + date2.getYear() + "-" + date2.getMonth() + "-" + date2.getDay());
    }
}

