import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.sql.*;

public class StaffManager extends Application {

    // Text fields
    private TextField tfID = new TextField();
    private TextField tfLastName = new TextField();
    private TextField tfFirstName = new TextField();
    private TextField tfMi = new TextField();
    private TextField tfAddress = new TextField();
    private TextField tfCity = new TextField();
    private TextField tfState = new TextField();
    private TextField tfTelephone = new TextField();
    private TextField tfEmail = new TextField();

    @Override
    public void start(Stage primaryStage) {
        // Grid layout
        GridPane pane = new GridPane();
        pane.setPadding(new Insets(10));
        pane.setHgap(5);
        pane.setVgap(5);

        // Labels and fields
        pane.add(new Label("ID:"), 0, 0); pane.add(tfID, 1, 0);
        pane.add(new Label("Last Name:"), 0, 1); pane.add(tfLastName, 1, 1);
        pane.add(new Label("First Name:"), 0, 2); pane.add(tfFirstName, 1, 2);
        pane.add(new Label("MI:"), 0, 3); pane.add(tfMi, 1, 3);
        pane.add(new Label("Address:"), 0, 4); pane.add(tfAddress, 1, 4);
        pane.add(new Label("City:"), 0, 5); pane.add(tfCity, 1, 5);
        pane.add(new Label("State:"), 0, 6); pane.add(tfState, 1, 6);
        pane.add(new Label("Telephone:"), 0, 7); pane.add(tfTelephone, 1, 7);
        pane.add(new Label("Email:"), 0, 8); pane.add(tfEmail, 1, 8);

        // Buttons
        HBox buttons = new HBox(10);
        Button btView = new Button("View");
        Button btInsert = new Button("Insert");
        Button btUpdate = new Button("Update");
        buttons.getChildren().addAll(btView, btInsert, btUpdate);
        buttons.setPadding(new Insets(10, 0, 0, 0));

        VBox layout = new VBox(10, pane, buttons);
        layout.setPadding(new Insets(10));

        // Button actions
        btView.setOnAction(e -> viewStaff());
        btInsert.setOnAction(e -> insertStaff());
        btUpdate.setOnAction(e -> updateStaff());

        // Show window
        Scene scene = new Scene(layout);
        primaryStage.setTitle("Staff Manager");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    // Connect to database
    private Connection connect() throws SQLException {
        return DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/your_database_name", "root", ""
        );
    }

    // View staff record
    private void viewStaff() {
        try (Connection conn = connect()) {
            String query = "SELECT * FROM Staff WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, tfID.getText());
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                tfLastName.setText(rs.getString("lastName"));
                tfFirstName.setText(rs.getString("firstName"));
                tfMi.setText(rs.getString("mi"));
                tfAddress.setText(rs.getString("address"));
                tfCity.setText(rs.getString("city"));
                tfState.setText(rs.getString("state"));
                tfTelephone.setText(rs.getString("telephone"));
                tfEmail.setText(rs.getString("email"));
            } else {
                showAlert("Staff not found.");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Insert staff record
    private void insertStaff() {
        try (Connection conn = connect()) {
            String insert = "INSERT INTO Staff VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(insert);
            stmt.setString(1, tfID.getText());
            stmt.setString(2, tfLastName.getText());
            stmt.setString(3, tfFirstName.getText());
            stmt.setString(4, tfMi.getText());
            stmt.setString(5, tfAddress.getText());
            stmt.setString(6, tfCity.getText());
            stmt.setString(7, tfState.getText());
            stmt.setString(8, tfTelephone.getText());
            stmt.setString(9, tfEmail.getText());
            stmt.executeUpdate();
            showAlert("Staff inserted.");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Update staff record
    private void updateStaff() {
        try (Connection conn = connect()) {
            String update = "UPDATE Staff SET lastName=?, firstName=?, mi=?, address=?, city=?, state=?, telephone=?, email=? WHERE id=?";
            PreparedStatement stmt = conn.prepareStatement(update);
            stmt.setString(1, tfLastName.getText());
            stmt.setString(2, tfFirstName.getText());
            stmt.setString(3, tfMi.getText());
            stmt.setString(4, tfAddress.getText());
            stmt.setString(5, tfCity.getText());
            stmt.setString(6, tfState.getText());
            stmt.setString(7, tfTelephone.getText());
            stmt.setString(8, tfEmail.getText());
            stmt.setString(9, tfID.getText());
            stmt.executeUpdate();
            showAlert("Staff updated.");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Show alert
    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Info");
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}

