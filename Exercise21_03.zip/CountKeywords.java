import java.io.*;
import java.util.*;

public class CountKeywords {
    public static void main(String[] args) throws Exception {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a Java source file: ");
        String filename = input.nextLine();

        File file = new File(filename);
        if (!file.exists()) {
            System.out.println("File " + filename + " does not exist.");
            System.exit(1);
        }

        System.out.println("The number of keywords in " + filename + " is " + countKeywords(file));
    }

    public static int countKeywords(File file) throws Exception {
        // List of Java keywords
        String[] keywordString = {
            "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class", "const",
            "continue", "default", "do", "double", "else", "enum", "extends", "final", "finally", "float",
            "for", "goto", "if", "implements", "import", "instanceof", "int", "interface", "long", "native",
            "new", "package", "private", "protected", "public", "return", "short", "static", "strictfp",
            "super", "switch", "synchronized", "this", "throw", "throws", "transient", "try", "void",
            "volatile", "while", "true", "false", "null"
        };

        Set<String> keywordSet = new HashSet<>(Arrays.asList(keywordString));
        int count = 0;

        Scanner input = new Scanner(file);

        boolean inBlockComment = false;

        while (input.hasNextLine()) {
            String line = input.nextLine().trim();

            // Handle block comments
            if (inBlockComment) {
                if (line.contains("*/")) {
                    inBlockComment = false;
                    line = line.substring(line.indexOf("*/") + 2);
                } else {
                    continue;
                }
            }

            if (line.startsWith("//")) continue; // Line comment
            if (line.contains("/*")) {
                inBlockComment = true;
                line = line.substring(0, line.indexOf("/*"));
            }

            // Remove string literals
            line = line.replaceAll("\".*?\"", "");

            String[] words = line.split("\\s+|(?=\\W)|(?<=\\W)");
            for (String word : words) {
                if (keywordSet.contains(word)) {
                    count++;
                }
            }
        }

        input.close();
        return count;
    }
}
